import{ NgModule } from '@angular/core';
import{ BotaoComponent } from './botao.component';

@NgModule({
  declarations: [ BotaoComponent],
  exports: [ BotaoComponent ]
})

export class BotaoModule{


}

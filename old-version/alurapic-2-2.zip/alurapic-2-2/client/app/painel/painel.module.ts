import { NgModule } from '@angular/core';
import { PainelComponent } from './painel.component';

@NgModule({
    declarations: [ PainelComponent ],
    exports: [ PainelComponent ]
})

export class PainelModule { }
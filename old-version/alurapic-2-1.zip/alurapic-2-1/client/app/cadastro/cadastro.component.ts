import { Component } from '@angular/core';
import { FotoComponent } from '../foto/foto.component';
import { Http, Headers } from '@angular/http';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
    moduleId: module.id,
    selector: 'cadastro',
    templateUrl: './cadastro.component.html'
})

export class CadastroComponent {

    //Instancia a classe foto component
    foto: FotoComponent = new FotoComponent();
    //Criando o metodo http como propriedade da classe
    http: Http;
    meuForm: FormGroup;
    /*Construtor feito para testar os dados de exibição na view
    constructor(){
        this.foto.titulo = "A";
        this.foto.url = "B";
        this.foto.descricao = "C";
    }*/
    //Define http no construtor da classe
    constructor(http: Http, fb: FormBuilder){

        this.http = http;
        this.meuForm = fb.group({
            titulo: ['', Validators.compose([Validators.required, Validators.minLength(4)])],
            url: ['', Validators.required],
            descricao: ['']
        });

    }

    cadastrar(event){

        event.preventDefault();
        console.log(this.foto);

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        //Os dados da foto são passados como json object
        this.http.post('v1/fotos', JSON.stringify(this.foto), { headers: headers } )
        .subscribe(() => {
            this.foto = new FotoComponent();
            console.log("Foto salva com sucesso");
        }, erro => console.log(erro));
    
    }

}// end - cadastro component
import { Component } from '@angular/core';
import { Http} from '@angular/http';

@Component({
    moduleId: module.id,
    selector: 'listagem',
    templateUrl: './listagem.component.html'
})

export class ListagemComponent{ 

    fotos: Object[] = [];

    //Injetando uma instancia do http e passsando como parametro
    //Em typescript pode declarar e passar como parametro o http: Http no lugar do @Inject, assim fica parecido com a declaração de variável
    constructor( http: Http ){

        http
        .get('v1/fotos')
        .map(res => res.json())
        .subscribe(fotos => {
            this.fotos = fotos;
            console.log(this.fotos);
        }, erro => console.log(erro));

    }

}